import java.io.File;
import java.io.FileNotFoundException;
import java.util.*;

public class FileSummary {
    private String book_location;
    private File book;
    private HashMap<String, Integer> allUniques;
    public FileSummary(String book_path) {
        book_location=book_path;
        boolean dot_txt = (book_location.endsWith(".txt"));
        if(!dot_txt) {
            book_location = book_location + ".txt";
        }
        this.allUniques = new HashMap<String, Integer>();
    }
    public void load_book() {
        this.book = new File(book_location);
        Scanner bookworm;
        try {
            bookworm=new Scanner(book);
            int lineCounter=0;
            while (bookworm.hasNextLine()) {
                lineCounter++;
                String line;
                String[] words;
                line=bookworm.nextLine().toLowerCase(Locale.ROOT);
                //System.out.println(lineCounter + " --- " + line);
                line=line.replaceAll("-", " ");
                words=line.split(" ");
                //System.out.println(lineCounter + " --- " + Arrays.toString(words));
                int lineLength=words.length;
                //System.out.println(lineCounter + " --- " + Arrays.toString(words));
                for(int lineIndex = 0; lineIndex<lineLength; lineIndex++){
                    words[lineIndex]=words[lineIndex].replaceAll("[\\W]", "");
                    if(!(words[lineIndex].isEmpty())){
                        word_count(words[lineIndex], false);
                        //System.out.println("'" + line[lineIndex] + "' is used " + allUniques.get(line[lineIndex]) + " times.");
                    }
                    //System.out.print(line[lineIndex]);
                }
                //System.out.println(lineCounter + " --- " + Arrays.toString(words));
                //System.out.print("\n");
            }
        }catch(FileNotFoundException e){
            System.out.println("File Not Found!");
        }
    }

    public int get_unique_word_count() {
        int keyCount=allUniques.keySet().size();;
        return keyCount;

    }
    public String get_all_word_counts() {
        String totalCounts="";
        for (Map.Entry<String, Integer> entry : allUniques.entrySet()) {
            String uniqueWord = entry.getKey();
            Integer times = entry.getValue();
            if(!(uniqueWord.isEmpty())) {
                totalCounts += times+"x  '" + uniqueWord + "'\n";
            }
        }
        return totalCounts;
    }

    public void word_count(String word, boolean done) {
        String eachCount="";
        int wordFrequency = allUniques.getOrDefault(word, 0);
        allUniques.put(word, (wordFrequency+1));
    }
    public String toString(){
        String info="\n" + book_location + " contains this many: \n";
        return info;
    }
}
