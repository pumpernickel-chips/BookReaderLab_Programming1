import java.util.Scanner;

public class Lab7 {
    public static void main(String arg[]) {
        boolean quit=false;
        while(!quit) {
            Scanner choose_file = new Scanner(System.in);
            System.out.print("\nPlease enter book title/filepath (or enter q to quit): ");
            String book_path = choose_file.nextLine();
            if(!(book_path.equalsIgnoreCase("q"))){
                FileSummary book_of_choice = new FileSummary(book_path);
                String book_title = book_path.substring(0, 1).toUpperCase() + book_path.substring(1);
                book_of_choice.load_book();
                System.out.print("\nThere are " + book_of_choice.get_unique_word_count() + " unique words in " + book_title + ".\nShow # of repetitions of each unique word in " + book_title + "? Y/N: ");
                Scanner yn = new Scanner(System.in);
                String ynAns = yn.next();
                if (ynAns.equalsIgnoreCase("y")) {
                    System.out.print("\nFrequency of Each Unique Word in " + book_path.toUpperCase() + ":\n====================================================\n" + book_of_choice.get_all_word_counts());
                }
                System.out.println("\n====================================================\n");
            }else{
                quit=true;
            }
        }
        System.out.println("\n\nGoodbye!");
    }
}
